# 📋 Чеклист универсальной системы управления данными

## 🚀 Быстрый старт

### Основные команды

```bash
# Миграция метаданных dev → prod
npm run data:migrate-dev-to-prod

# Засев метаданных в текущую БД
npm run data:seed-metadata

# Засев в production
npm run data:seed-prod

# Полная синхронизация
npm run data:full-sync
```

## ✅ Чеклист добавления новых данных

### 1. Планирование

- [ ] Определить категорию данных (static_metadata, core_metadata, business_metadata, content_data, user_data, relationship_data)
- [ ] Выявить зависимости от других таблиц
- [ ] Определить объем данных (нужна ли батчевая обработка)
- [ ] Проверить наличие чувствительных полей для исключения
- [ ] Планировать трансформации данных (если нужны)

### 2. Конфигурация

- [ ] Добавить таблицу в `config/migration-config.ts`
- [ ] Указать правильную категорию и порядок
- [ ] Настроить зависимости
- [ ] Выбрать тип обработки (normal, hierarchical, batch, custom)
- [ ] Исключить чувствительные поля
- [ ] Добавить трансформации

### 3. Скрипт засева

- [ ] Создать скрипт `scripts/seed-{table-name}.ts`
- [ ] Использовать `upsert` вместо `create` для предотвращения дубликатов
- [ ] Добавить обработку ошибок
- [ ] Тестировать скрипт отдельно

### 4. Интеграция

- [ ] Обновить mapping в `scripts/data-seeding-manager.ts`
- [ ] Добавить npm команду в `package.json` (при необходимости)
- [ ] Обновить документацию

### 5. Тестирование

- [ ] Тестовый запуск: `npm run migrate:universal -- --dry-run`
- [ ] Тестирование засева: `npm run seed:managed -- --tables new_table`
- [ ] Проверка зависимостей: `node -e "console.log(require('./config/migration-config').validateDependencies())"`
- [ ] Проверка в dev окружении

### 6. Деплой

- [ ] Создать backup: `pg_dump > backup.sql`
- [ ] Развернуть код
- [ ] Запустить миграцию/засев
- [ ] Проверить результаты: `npm run verify:metadata`

## 📋 Шаблоны

### Конфигурация новой таблицы

```typescript
{
  tableName: 'tableName',
  displayName: 'Отображаемое имя',
  icon: '📝',
  dependencies: ['dependency1', 'dependency2'], // опционально
  specialHandling: 'batch', // 'normal' | 'hierarchical' | 'batch' | 'custom'
  batchSize: 100, // для больших таблиц
  excludeFields: ['sensitiveField1', 'sensitiveField2'],
  transformations: {
    email: (email: string) => email.toLowerCase(),
    // другие трансформации
  }
}
```

### Скрипт засева

```typescript
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function seedTableName() {
  console.log('🌱 Засеваем TableName...');
  
  const data = [
    // ваши данные
  ];

  for (const item of data) {
    await prisma.tableName.upsert({
      where: { uniqueField: item.uniqueField },
      update: item,
      create: item
    });
  }
  
  console.log(`✅ Засеяно ${data.length} записей`);
}

if (require.main === module) {
  seedTableName()
    .catch(console.error)
    .finally(() => prisma.$disconnect());
}
```

## ⚡ Частые сценарии

### Добавление справочника

```bash
# 1. Добавить в static_metadata или core_metadata
# 2. Создать скрипт засева
# 3. Тестировать
npm run seed:managed -- --tables new_reference --dry-run
# 4. Засеять
npm run seed:managed -- --tables new_reference
```

### Добавление большой таблицы контента

```bash
# 1. Добавить в content_data с specialHandling: 'batch'
# 2. Установить подходящий batchSize
# 3. Тестировать батчами
npm run migrate:universal -- --tables large_table --batch-size 50 --dry-run
# 4. Мигрировать
npm run migrate:universal -- --tables large_table --batch-size 50
```

### Добавление связей (many-to-many)

```bash
# 1. Добавить в relationship_data
# 2. Указать зависимости от связываемых таблиц
# 3. Засеять после основных таблиц
npm run seed:managed -- --categories static_metadata,core_metadata,business_metadata
npm run seed:managed -- --categories relationship_data
```

## 🔍 Диагностика

### Проверки перед деплоем

```bash
# Валидация конфигурации
node -e "console.log(require('./config/migration-config').validateDependencies())"

# Тестовый запуск
npm run migrate:universal -- --dry-run

# Проверка скриптов засева
npm run seed:managed -- --categories static_metadata --skip-existing
```

### Проверки после деплоя

```bash
# Количество записей
npm run verify:metadata

# Проверка конкретной таблицы
docker-compose exec postgres psql -U user -d db -c "SELECT COUNT(*) FROM table_name;"

# Проверка связей
docker-compose exec postgres psql -U user -d db -c "SELECT COUNT(*) FROM slide_tags;"
```

## 🚨 Troubleshooting

### Проблема: Foreign key constraint

**Решение:**
- Проверить порядок зависимостей в конфигурации
- Убедиться, что родительские таблицы мигрируются первыми

### Проблема: Дублирование данных

**Решение:**
- Использовать `upsert` вместо `create`
- Проверить уникальные поля в `where` условии

### Проблема: Timeout при больших данных

**Решение:**
- Уменьшить `batchSize`
- Использовать `specialHandling: 'batch'`
- Увеличить timeout соединения

### Проблема: Скрипт не найден

**Решение:**
- Создать скрипт засева
- Обновить mapping в `data-seeding-manager.ts`
- Проверить путь к скрипту

## 📊 Мониторинг производительности

### Оптимальные размеры батчей

- **Малые справочники** (< 100 записей): обычная обработка
- **Средние таблицы** (100-1000 записей): batch 50-100
- **Большие таблицы** (> 1000 записей): batch 20-50
- **Очень большие** (> 10000): batch 10-20 + параллельность

### Команды для мониторинга

```bash
# Засев с ограничением потоков
npm run seed:managed -- --parallel --max-concurrency 3

# Батчевая миграция
npm run migrate:universal -- --batch-size 25

# Частичная миграция для тестирования
npm run migrate:universal -- --categories static_metadata --dry-run
``` 