# Универсальное руководство по управлению данными

## Обзор

Данное руководство описывает универсальную систему управления данными в SlideDeck 2.0, которая позволяет гибко работать с любыми типами данных, а не только с метаданными.

## Архитектура системы

### 🏗️ Структура системы

```
config/
├── migration-config.ts      # Конфигурация таблиц и категорий данных
├── 
scripts/
├── universal-data-migration.ts    # Универсальный скрипт миграции
├── data-seeding-manager.ts        # Менеджер засева данных
├── [конкретные скрипты засева]    # Отдельные скрипты для таблиц
```

### 📊 Категории данных

Система поддерживает следующие категории данных:

1. **static_metadata** - Статические метаданные (статусы, форматы, языки, регионы)
2. **core_metadata** - Основные метаданные (категории, теги, домены, области решений)
3. **business_metadata** - Бизнес метаданные (продукты, компоненты, интеграции, типы пользователей)
4. **content_data** - Контентные данные (слайды)
5. **user_data** - Пользовательские данные (пользователи)
6. **relationship_data** - Связи между сущностями (many-to-many отношения)

## 🔧 Использование

### Основные команды

```bash
# Универсальная миграция данных
npm run migrate:universal [опции]

# Управляемый засев данных
npm run seed:managed [опции]

# Готовые сценарии
npm run data:migrate-dev-to-prod    # Миграция метаданных из dev в prod
npm run data:seed-metadata          # Засев только метаданных
npm run data:seed-prod              # Засев в production
npm run data:full-sync              # Полная синхронизация
```

### Опции для универсальной миграции

```bash
# Мигрировать конкретные категории
npm run migrate:universal -- --categories static_metadata,core_metadata

# Мигрировать конкретные таблицы
npm run migrate:universal -- --tables category,tag,product

# Тестовый запуск
npm run migrate:universal -- --dry-run

# Очистить целевую БД перед миграцией
npm run migrate:universal -- --clear

# Настроить размер батча для больших таблиц
npm run migrate:universal -- --batch-size 50
```

### Опции для управляемого засева

```bash
# Засеять конкретные категории
npm run seed:managed -- --categories static_metadata,core_metadata

# Засеять в конкретную среду
npm run seed:managed -- --env prod

# Параллельный засев
npm run seed:managed -- --parallel --max-concurrency 3

# Пропустить таблицы с данными
npm run seed:managed -- --skip-existing

# Принудительно перезаписать данные
npm run seed:managed -- --force
```

## 📋 Конфигурация

### Добавление новых таблиц

Для добавления новой таблицы в систему:

1. **Обновите конфигурацию** в `config/migration-config.ts`:

```typescript
{
  tableName: 'newTable',
  displayName: 'Новая таблица',
  icon: '📝',
  dependencies: ['dependency1'], // Опционально
  specialHandling: 'batch',      // Опционально
  batchSize: 100,               // Опционально
  excludeFields: ['sensitiveField'], // Опционально
  transformations: {            // Опционально
    email: (email: string) => email.toLowerCase()
  }
}
```

2. **Создайте скрипт засева** (если нужен):

```typescript
// scripts/seed-new-table.ts
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function seedNewTable() {
  console.log('🌱 Засеваем новую таблицу...');
  
  const data = [
    { name: 'Запись 1' },
    { name: 'Запись 2' }
  ];

  for (const item of data) {
    await prisma.newTable.upsert({
      where: { name: item.name },
      update: item,
      create: item
    });
  }
  
  console.log(`✅ Засеяно ${data.length} записей`);
}

if (require.main === module) {
  seedNewTable()
    .catch(console.error)
    .finally(() => prisma.$disconnect());
}
```

3. **Обновите скрипт засева менеджера** в `scripts/data-seeding-manager.ts`:

```typescript
const scriptMap: Record<string, string> = {
  // ... существующие скрипты
  'newTable': 'scripts/seed-new-table.ts'
};
```

### Специальная обработка

Система поддерживает несколько типов специальной обработки:

#### Иерархическая структура ('hierarchical')
Для таблиц с parent-child отношениями (например, категории):
- Сначала мигрируются корневые элементы
- Затем дочерние элементы

#### Батчевая обработка ('batch')
Для больших таблиц:
- Данные обрабатываются порциями
- Настраивается размер батча

#### Кастомная обработка ('custom')
Для особых случаев:
- Указывается имя функции кастомной обработки

## 🚀 Сценарии использования

### Развертывание новой функциональности

```bash
# 1. Деплой кода на сервер
git push origin main

# 2. Подключение к серверу
ssh root@your-server

# 3. Обновление кода
cd /path/to/app
git pull origin main

# 4. Миграция новых метаданных
docker-compose -f docker-compose.prod.yml exec app npm run data:migrate-dev-to-prod

# 5. Проверка результатов
docker-compose -f docker-compose.prod.yml exec app npm run verify:metadata
```

### Засев данных в новое окружение

```bash
# Полный засев всех метаданных
npm run seed:managed -- --categories static_metadata,core_metadata,business_metadata

# Засев с пропуском существующих данных
npm run seed:managed -- --skip-existing

# Параллельный засев для ускорения
npm run seed:managed -- --parallel --max-concurrency 5
```

### Синхронизация между окружениями

```bash
# Из dev в prod (только метаданные)
npm run data:migrate-dev-to-prod

# Полная синхронизация
npm run data:full-sync

# Синхронизация конкретных таблиц
npm run migrate:universal -- --tables category,product,tag --clear
```

### Обработка больших объемов данных

```bash
# Миграция слайдов батчами
npm run migrate:universal -- --tables slide --batch-size 100

# Параллельный засев контента
npm run seed:managed -- --categories content_data --parallel
```

## 🔍 Мониторинг и отладка

### Тестовый запуск

Всегда тестируйте изменения перед применением:

```bash
# Тестовый запуск миграции
npm run migrate:universal -- --dry-run

# Проверка конфигурации
node -e "console.log(require('./config/migration-config').validateDependencies())"
```

### Логирование

Система предоставляет подробные логи:

```
🚀 Начинаем универсальную миграцию данных...
📅 Время начала: 2024-01-15T10:30:00.000Z

📋 Планируется мигрировать следующие таблицы:
   📊 Статусы (status)
   📄 Форматы (format)
   🌍 Языки (language)

📊 Статусы...
   ✅ Мигрировано: 5/5 записей за 150мс

🎉 Миграция завершена!
═══════════════════════════════════════════
✅ status              |      5/     5 |   150мс
✅ format              |      8/     8 |   200мс
✅ language            |     12/    12 |   180мс
═══════════════════════════════════════════
📈 ИТОГО: 25/25 записей, 0 ошибок
⏱️  Общее время: 530мс
```

### Проверка результатов

```bash
# Проверка метаданных
npm run verify:metadata

# Проверка конкретной таблицы
docker-compose -f docker-compose.prod.yml exec postgres psql -U slidebox -d slidebox -c "SELECT COUNT(*) FROM categories;"
```

## 🛠️ Настройка окружений

### Переменные окружения

```bash
# Development
DATABASE_URL_DEV="postgresql://user:pass@host:port/db_dev"

# Production  
DATABASE_URL_PROD="postgresql://user:pass@host:port/db_prod"

# Staging (опционально)
DATABASE_URL_STAGING="postgresql://user:pass@host:port/db_staging"
```

### Docker конфигурация

Обновите `docker-compose.prod.yml` для поддержки новых команд:

```yaml
services:
  app:
    environment:
      - DATABASE_URL_DEV=${DATABASE_URL_DEV}
      - DATABASE_URL_PROD=${DATABASE_URL_PROD}
```

## 🔐 Безопасность

### Исключение чувствительных данных

Система автоматически исключает чувствительные поля:

```typescript
{
  tableName: 'user',
  excludeFields: ['password', 'resetToken', 'resetTokenExpiry']
}
```

### Трансформации данных

Применяйте трансформации для обеспечения целостности:

```typescript
{
  tableName: 'user',
  transformations: {
    email: (email: string) => email.toLowerCase(),
    phone: (phone: string) => phone.replace(/\D/g, '')
  }
}
```

## 📈 Производительность

### Оптимизация миграции

- Используйте батчевую обработку для больших таблиц
- Настройте размер батча в зависимости от объема данных
- Используйте параллельный засев когда возможно

### Мониторинг производительности

```bash
# Миграция с детальным логированием времени
npm run migrate:universal -- --categories content_data --batch-size 50

# Параллельный засев с ограничением потоков
npm run seed:managed -- --parallel --max-concurrency 3
```

## 🚨 Устранение неполадок

### Частые проблемы

1. **Нарушение foreign key constraints**
   - Решение: Проверьте порядок зависимостей в конфигурации

2. **Дублирование данных**
   - Решение: Используйте `upsert` вместо `create`

3. **Превышение времени ожидания**
   - Решение: Уменьшите размер батча или увеличьте timeout

4. **Отсутствие скрипта засева**
   - Решение: Создайте скрипт или обновите mapping в менеджере

### Откат изменений

```bash
# Создание backup'а перед миграцией
docker-compose -f docker-compose.prod.yml exec postgres pg_dump -U slidebox slidebox > backup_$(date +%Y%m%d_%H%M%S).sql

# Восстановление из backup'а
docker-compose -f docker-compose.prod.yml exec -T postgres psql -U slidebox -d slidebox < backup_file.sql
```

## 📝 Примеры использования

### Добавление новой категории данных

```typescript
// В config/migration-config.ts добавьте:
{
  categoryName: 'analytics_data',
  description: 'Аналитические данные',
  order: 7,
  tables: [
    {
      tableName: 'metric',
      displayName: 'Метрики',
      icon: '📊',
      batchSize: 1000,
      specialHandling: 'batch'
    }
  ]
}
```

### Миграция только новых данных

```bash
# Мигрировать только новую категорию
npm run migrate:universal -- --categories analytics_data

# Засеять только новые таблицы
npm run seed:managed -- --tables metric,report --env prod
```

## 🎯 Заключение

Универсальная система управления данными предоставляет:

- **Гибкость** - легко добавлять новые типы данных
- **Безопасность** - автоматическое исключение чувствительной информации
- **Производительность** - батчевая и параллельная обработка
- **Надежность** - валидация зависимостей и откат изменений
- **Простоту** - готовые команды для типовых сценариев

Эта система масштабируется вместе с вашим проектом и легко адаптируется под новые требования. 