import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const slideId = params.id;

    // Обновляем статус слайда
    const slide = await prisma.slide.update({
      where: { id: slideId },
      data: {
        isActive: true,
        updatedAt: new Date()
      }
    });

    return NextResponse.json({
      success: true,
      slide: {
        id: slide.id,
        title: slide.title,
        isActive: slide.isActive
      }
    });

  } catch (error) {
    console.error('Error publishing slide:', error);
    return NextResponse.json(
      { error: 'Failed to publish slide' },
      { status: 500 }
    );
  }
} 