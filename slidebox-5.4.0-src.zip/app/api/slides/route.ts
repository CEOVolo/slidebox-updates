import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Маркируем как динамический: используется request.url (page, limit, category, query)
export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    
    // Get basic parameters
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '100');
    const category = searchParams.get('category');
    const query = searchParams.get('query');

    // Build where clause
    const where: any = {
      isActive: true,
    };

    // Category filter (supports 'all', 'uncategorized', and parent categories including descendants)
    if (category && category !== 'all') {
      if (category === 'uncategorized') {
        // Slides without any categories
        // @ts-ignore - Prisma types
        where.SlideCategory = { none: {} };
      } else {
        // Resolve descendants for parent category selection (up to 2 levels deep)
        // @ts-ignore - Prisma types
        const selectedCategory = await prisma.category.findUnique({
          where: { id: category },
          include: {
            children: {
              include: { children: true }
            }
          }
        });

        const categoryIds: string[] = [];
        if (selectedCategory) {
          categoryIds.push(selectedCategory.id);
          if (selectedCategory.children) {
            for (const child of selectedCategory.children as any[]) {
              if (child?.id) categoryIds.push(child.id);
              if (child?.children) {
                for (const grand of child.children as any[]) {
                  if (grand?.id) categoryIds.push(grand.id);
                }
              }
            }
          }
        }

        // @ts-ignore - Prisma types
        where.SlideCategory = categoryIds.length > 0
          ? { some: { categoryId: { in: categoryIds } } }
          : { some: { categoryId: category } };
      }
    }

    // Server-side text search
    if (query && query.trim()) {
      const text = query.trim();
      where.OR = [
        { title: { contains: text, mode: 'insensitive' } },
        { description: { contains: text, mode: 'insensitive' } },
        { extractedText: { contains: text, mode: 'insensitive' } },
        // @ts-ignore - Prisma types
        { tags: { some: { tag: { name: { contains: text, mode: 'insensitive' } } } } }
      ];
    }

    // Get slides from database
    const slides = await prisma.slide.findMany({
      where,
      include: {
        // @ts-ignore - Prisma types
        SlideCategory: {
          include: {
            Category: true,
          },
        },
        tags: {
          include: {
            tag: true,
          },
        },
        solutionAreas: {
          include: {
            solutionArea: true,
          },
        },
        products: {
          include: {
            product: true,
          },
        },
        // @ts-ignore - Prisma types
        SlideConfidentiality: {
          include: {
            Confidentiality: true,
          },
        },
        components: {
          include: {
            component: true,
          },
        },
        integrations: {
          include: {
            integration: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
      skip: (page - 1) * limit,
      take: limit,
    });

    // Get total count
    const total = await prisma.slide.count({ where });

    return NextResponse.json({
      slides,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
      hasMore: page * limit < total,
    });
  } catch (error) {
    console.error('Error fetching slides:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { title, description, categoryIds, figmaFileId, figmaNodeId, imageUrl, extractedText, tags } = body;

    // Create slide
    const slide = await prisma.slide.create({
      data: {
        title,
        description,
        figmaFileId,
        figmaNodeId,
        imageUrl,
        extractedText,
        // @ts-ignore - Prisma types
        SlideCategory: categoryIds && Array.isArray(categoryIds) ? {
          create: categoryIds.map((categoryId: string) => ({ categoryId }))
        } : undefined,
      },
      include: {
        // @ts-ignore - Prisma types
        SlideCategory: {
          include: {
            Category: true,
          },
        },
        tags: {
          include: {
            tag: true,
          },
        },
      },
    });

    // Get updated slide with all relations
    const updatedSlide = await prisma.slide.findUnique({
      where: { id: slide.id },
      include: {
        // @ts-ignore - Prisma types
        SlideCategory: {
          include: {
            Category: true,
          },
        },
        tags: {
          include: {
            tag: true,
          },
        },
      },
    });

    return NextResponse.json(updatedSlide, { status: 201 });
  } catch (error) {
    console.error('Error creating slide:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 