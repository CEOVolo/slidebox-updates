# 🏷️ Обновленная система тегов SlideDeck 2.0

## 📋 **Изменения в системе**

### ✅ **Что изменилось:**

1. **Теги больше НЕ создаются автоматически при импорте** из Figma
2. **Теги создаются ТОЛЬКО при извлечении текста** в модерации  
3. **Теги генерируются из ДВУХ источников:**
   - Извлеченный текст слайда (как раньше)
   - Метаданные слайда (НОВОЕ!)

### 🎯 **Места применения тегов:**

| **Действие** | **Создание тегов** | **Статус** |
|-------------|-------------------|------------|
| Импорт из Figma | ❌ НЕТ | Отключено |
| Извлечение текста | ✅ ДА | Основной способ |
| Создание через API | ❌ НЕТ | Отключено |

## 🤖 **АВТОЗАПОЛНЕНИЕ МЕТАДАННЫХ**

### **Что автоматически определяется:**

| **Поле** | **Способ определения** | **Точность** |
|----------|----------------------|--------------|
| **Domain** | Ключевые слова: fintech, healthcare, ecommerce | 🟢 Высокая |
| **Format** | Размеры слайда (width > height = horizontal) | 🟢 100% |
| **Language** | Детекция символов (кириллица, латиница, умлауты) | 🟢 Высокая |
| **Case Study** | Слова: case, project, success, result | 🟢 Высокая |
| **Department** | Контекст: marketing, engineering, sales | 🟡 Средняя |
| **Years** | Даты формата 20XX в тексте | 🟡 Средняя |
| **Status** | По умолчанию "draft" для новых | 🟢 100% |
| **Region** | На основе языка + географические маркеры | 🟡 Средняя |

### **Примеры автозаполнения:**

**Текст:** "Mobile banking application for iOS development team in 2023"
```json
{
  "domain": "fintech",           // banking → fintech
  "department": "engineering",   // development → engineering
  "format": "horizontal",        // ширина > высоты
  "language": "en",             // латинские символы
  "yearStart": 2023,            // год из текста
  "status": "draft",            // по умолчанию
  "region": "global"            // английский язык
}
```

## 🔧 **Новая логика генерации тегов**

### **1. Теги из текста** (как раньше)
```typescript
// Из lib/textExtraction.ts - generateTagsFromText()
- web-development, mobile-development, design
- react, nodejs, python, docker, aws
- ecommerce, fintech, healthcare, saas
- cover, case, analytics, team
```

### **2. Теги из метаданных** (НОВОЕ!)
```typescript
// Из lib/textExtraction.ts - generateTagsFromMetadata()
- domain-fintech, domain-healthcare
- dept-marketing, dept-engineering  
- format-horizontal, format-vertical
- lang-english, lang-french
- region-emea, region-global
- status-approved, status-draft
- case-study (если isCaseStudy = true)
- year-2023, year-2024
- author-john-doe
```

### **3. Объединенные теги**
```typescript
// generateCombinedTags() объединяет оба источника
// Удаляет дубликаты, ограничивает до 15 тегов
```

## 🚀 **Как использовать**

### **В модерации:**
1. Выберите слайд
2. Нажмите кнопку **"Extract Text"** 
3. Система автоматически:
   - Извлечет текст из Figma
   - **🤖 АВТОЗАПОЛНИТ МЕТАДАННЫЕ** на основе контента
   - Создаст теги из текста + автозаполненных метаданных
   - Покажет результат и изменения

### **Для разработчиков:**
```typescript
import { generateCombinedTags } from '@/lib/textExtraction';

const tags = generateCombinedTags(
  extractedText, 
  {
    domain: 'fintech',
    department: 'marketing', 
    format: 'horizontal',
    language: 'en',
    region: 'emea',
    status: 'approved',
    isCaseStudy: true,
    yearStart: 2023
  }
);
```

## 📊 **Примеры результатов**

### **Финтех слайд о мобильном приложении:**

**Исходный текст:** "Mobile banking app for iOS and Android with React Native. Our team developed this solution in 2023"

**Автозаполненные метаданные:**
- Domain: fintech *(автоматически: banking → fintech)*
- Department: engineering *(автоматически: developed → engineering)*
- Format: horizontal *(автоматически: ширина > высоты)*
- Language: en *(автоматически: латинские символы)*
- Year: 2023 *(автоматически: из текста)*
- Case Study: false *(автоматически: нет ключевых слов)*

**Результирующие теги:**
```
domain-fintech, dept-engineering, format-horizontal, lang-en, year-2023,
mobile-development, react, development, frontend, ios, android
```

**🎯 Без автозаполнения:** 6 тегов только из текста  
**✅ С автозаполнением:** 11 тегов (текст + метаданные)

## 🔄 **Миграция**

### **Старые теги:** 
- Остаются в базе данных
- Продолжают работать в поиске
- НЕ удаляются автоматически

### **Новые теги:**
- Создаются при каждом извлечении текста
- Заменяют старые теги слайда
- Более структурированные и информативные

## ⚙️ **Технические детали**

### **Функции:**
- `autoFillMetadata()` - 🤖 **НОВОЕ!** автозаполнение метаданных
- `generateTagsFromText()` - теги из текста
- `generateTagsFromMetadata()` - теги из метаданных  
- `generateCombinedTags()` - объединение
- `processSlideContent()` - полная обработка

### **API Endpoint:**
```
POST /api/slides/[id]/extract-text

Response:
{
  "extractedText": "...",
  "tags": [{"id": "...", "name": "..."}],
  "suggestedTitle": "...",
  "autoFilledMetadata": {
    "original": {...},
    "updated": {...},
    "changes": ["domain", "format", "language"]
  }
}
```

### **База данных:**
```sql
Tag {
  name: string (unique)
  isAutomatic: boolean  -- true для автотегов
  usageCount: number   -- счетчик использования
}

SlideTag {
  slideId: string
  tagId: string
}
```

## 🎨 **Улучшения UX**

1. **Более релевантные теги** - учитывают контекст метаданных
2. **Структурированные названия** - префиксы для категорий
3. **Больше информации** - до 15 тегов вместо 10
4. **Контролируемое применение** - только при необходимости

---

**Дата обновления:** `r new Date().toISOString().split('T')[0]`  
**Версия системы:** 2.0  
**Ответственный:** AI Assistant 