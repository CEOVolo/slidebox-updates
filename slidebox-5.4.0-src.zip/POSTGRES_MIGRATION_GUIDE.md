# 🚀 Переход с SQLite на PostgreSQL

Это пошаговая инструкция для перехода вашего SlideDeck 2.0 с SQLite на PostgreSQL.

## Что уже сделано за вас:

✅ Обновлена схема Prisma для PostgreSQL  
✅ Добавлены необходимые зависимости (pg, @types/pg, sqlite3)  
✅ Создан Docker Compose для локальной разработки  
✅ Создан Dockerfile для продакшена  
✅ Создан скрипт переноса данных  
✅ Обновлены npm скрипты  

## ШАГ 1: Создайте файл .env.local

Создайте файл `.env.local` в корне проекта со следующим содержимым:

```bash
# База данных PostgreSQL
DATABASE_URL="postgresql://slidedeck_user:slidedeck_password@localhost:5432/slidedeck_db?schema=public"

# Figma API (вставьте ваш реальный токен)
FIGMA_ACCESS_TOKEN="your_figma_token_here"

# Next.js
NEXTAUTH_SECRET="your_nextauth_secret_here"
NEXTAUTH_URL="http://localhost:3000"
```

⚠️ **ВАЖНО**: Замените `your_figma_token_here` и `your_nextauth_secret_here` на ваши реальные значения!

## ШАГ 2: Установите Docker Desktop

1. Скачайте и установите **Docker Desktop** с официального сайта: https://www.docker.com/products/docker-desktop/
2. Запустите Docker Desktop
3. Убедитесь что Docker работает командой: `docker --version`

## ШАГ 3: Установите новые зависимости

```bash
npm install
```

## ШАГ 4: Запустите PostgreSQL в Docker

```bash
docker compose -f docker-compose.dev.yml up -d
```

Эта команда:
- Скачает образ PostgreSQL
- Создаст контейнер с базой данных
- Запустит его в фоновом режиме

Проверить что PostgreSQL запустился:
```bash
docker compose -f docker-compose.dev.yml ps
```

## ШАГ 5: Создайте таблицы в PostgreSQL

```bash
npm run db:push
```

Эта команда создаст все таблицы согласно вашей Prisma схеме.

## ШАГ 6: Перенесите данные из SQLite

```bash
npm run migrate-data
```

Скрипт автоматически перенесет все ваши данные:
- Пользователей
- Слайды  
- Теги
- Презентации
- Связи между ними

## ШАГ 7: Запустите приложение

```bash
npm run dev
```

Откройте http://localhost:3000 - ваше приложение должно работать с PostgreSQL!

## ШАГ 8: Проверьте что всё работает

1. ✅ Проверьте что слайды отображаются
2. ✅ Попробуйте создать новый слайд
3. ✅ Проверьте поиск
4. ✅ Проверьте создание презентации

## Возможные проблемы и решения:

### ❌ "Port 5432 is already in use"
Скорее всего у вас уже установлен PostgreSQL. Варианты:
1. Остановите локальный PostgreSQL: `net stop postgresql-x64-15` (в PowerShell как администратор)
2. Или измените порт в `docker-compose.dev.yml` на другой (например 5433)

### ❌ "Can't reach database server"
1. Проверьте что Docker запущен
2. Проверьте что контейнер работает: `docker compose -f docker-compose.dev.yml ps`
3. Перезапустите контейнер: `docker compose -f docker-compose.dev.yml restart`

### ❌ Ошибки при переносе данных
1. Убедитесь что файл `prisma/dev.db` существует
2. Запустите повторно: `npm run migrate-data`

## После успешного перехода:

1. **Сделайте бэкап старой базы**: Скопируйте `prisma/dev.db` в безопасное место
2. **Обновите .gitignore**: Добавьте `.env.local` в .gitignore если его там нет
3. **Готово к продакшену**: Теперь ваше приложение готово к деплою!

## Продакшен деплой:

Для деплоя используйте созданные файлы:
- `Dockerfile` - для сборки контейнера
- `docker-compose.yml` - для продакшен окружения  
- Установите переменную `DATABASE_URL` на продакшен сервере

---

🎉 **Поздравляю! Ваше приложение теперь использует PostgreSQL!**

Если возникнут проблемы - пишите, разберемся вместе. 